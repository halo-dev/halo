# theme-earth

Default theme for Halo 2.0(WIP)

## Build theme

> If you are using Windows OS, please install `make` command and execute `make` in Git Bash or WSL.

- Execute command `make build` to generate dist folder
- Zip the dist folder and upload to your Halo
